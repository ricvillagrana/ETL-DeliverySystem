<?php $__env->startSection('additional-css'); ?>
<style>
    
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard-content'); ?>
<h3> <?php echo e($tableName); ?> </h3>
<table id="table-head-freeze" class="table table-bordered table-hover table-light">
    <thead class="thead-light">
        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th scope="col"> <?php echo e($column); ?> </th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </thead>
    <tbody>
        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php $__currentLoopData = $params; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $param): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="p-1"> <?php echo e($row[$param]); ?> </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    
</table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-js'); ?>
<script>
        $(document).ready(function () {
            $("#table-head-freeze").freezeHeader({offset : '40px'});
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>