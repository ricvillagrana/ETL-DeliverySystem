<?php $__env->startSection('dashboard-content'); ?>
<div class="offset-md-2 col-md-10 col-12">
        <h2>Dashboard</h2>
        <p>Usamos datos de las siguientes APIs:</p>
        <div class="row">
            <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6 col-12 card margining box-shadow">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($source->name); ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($source->database); ?></h6>
                    <p class="card-text"><?php echo e($source->description); ?></p>
                    <a href="#" class="btn btn-dark pull-right">Ver datos</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>