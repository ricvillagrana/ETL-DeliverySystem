<?php $__env->startSection('dashboard-content'); ?>
<h3>Dashboard</h3>
<p>Puedes ver la sanidad de los datos:</p>

<div class="row">
    <div class="col-md-10 offset-1">
        <canvas id="percentage-chart" width="400" height="120"></canvas>
    </div>
    <div class="col-md-10 offset-1">
        <canvas id="tables-chart" width="400" height="120"></canvas>
    </div>  
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-js'); ?>
<script>
    var doughnut = document.getElementById("percentage-chart");
    var myDoughnutChart = new Chart(doughnut, {
        type: 'radar',
        data: {
            labels: [
            "Carga gas",
            "Conductores",
            "Devoluciones",
            "Envíos", 
            "Envíos vehículo día",
            "Órdenes",
            "Vehículo Día",
            ],
            datasets: [{
                label: 'Registros sanos',
                data: [
                <?php echo e($count['carga_gas']); ?>,
                <?php echo e($count['conductores']); ?>,
                <?php echo e($count['devoluciones']); ?>,
                <?php echo e($count['envios']); ?>,
                <?php echo e($count['envio_vehiculo_dia']); ?>,
                <?php echo e($count['ordenes']); ?>,
                <?php echo e($count['vehiculo_dia']); ?>,
                ],
                borderColor: [
                '#4594f2',
                ],
                borderWidth: 3
            },
            {
                label: 'Errores (En BD Dummie)',
                data: [
                <?php echo e($count['error_carga_gas']); ?>,
                <?php echo e($count['error_conductores']); ?>,
                <?php echo e($count['error_devoluciones']); ?>,
                <?php echo e($count['error_envios']); ?>,
                <?php echo e($count['error_envio_vehiculo_dia']); ?>,
                <?php echo e($count['error_ordenes']); ?>,
                <?php echo e($count['error_vehiculo_dia']); ?>,
                ],
                borderColor: [
                '#ff4570',
                ],
                borderWidth: 3
            },
            ]
        },
        options: {
        },
        animation: {
            duration: 2000
        }
    });
    var ctx = document.getElementById("tables-chart");
    var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [
            "Carga gas",
            "Conductores",
            "Devoluciones",
            "Envíos", 
            "Envíos vehículo día",
            "Órdenes",
            "Vehículo Día",
            ],
            datasets: [{
                label: 'Registros sanos',
                data: [
                <?php echo e($count['carga_gas']); ?>,
                <?php echo e($count['conductores']); ?>,
                <?php echo e($count['devoluciones']); ?>,
                <?php echo e($count['envios']); ?>,
                <?php echo e($count['envio_vehiculo_dia']); ?>,
                <?php echo e($count['ordenes']); ?>,
                <?php echo e($count['vehiculo_dia']); ?>,
                ],
                borderColor: [
                '#4594f2',
                ],
                borderWidth: 3
            },
            {
                label: 'Errores (En BD Dummie)',
                data: [
                <?php echo e($count['error_carga_gas']); ?>,
                <?php echo e($count['error_conductores']); ?>,
                <?php echo e($count['error_devoluciones']); ?>,
                <?php echo e($count['error_envios']); ?>,
                <?php echo e($count['error_envio_vehiculo_dia']); ?>,
                <?php echo e($count['error_ordenes']); ?>,
                <?php echo e($count['error_vehiculo_dia']); ?>,
                ],
                borderColor: [
                '#ff4570',
                ],
                borderWidth: 3
            },
            ]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        },
        animation: {
            duration: 2000
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>