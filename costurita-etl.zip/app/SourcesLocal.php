<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SourcesLocal extends Model
{
    //
}
